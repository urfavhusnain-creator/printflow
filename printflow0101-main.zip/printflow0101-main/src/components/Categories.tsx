import { motion } from "framer-motion";
import { Home, Building2, Palette, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const categories = [
  {
    icon: Home,
    title: "Home Printers",
    description: "Compact, affordable, and perfect for everyday printing needs. Great for families and students.",
    printers: 24,
    startingPrice: 79,
  },
  {
    icon: Building2,
    title: "Office Solutions",
    description: "High-volume, network-ready printers built for business productivity and team collaboration.",
    printers: 18,
    startingPrice: 299,
  },
  {
    icon: Palette,
    title: "Professional Series",
    description: "Museum-quality photo printing for photographers, artists, and creative professionals.",
    printers: 12,
    startingPrice: 899,
  },
];

const Categories = () => {
  return (
    <section id="categories" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Find Your <span className="text-gradient">Perfect Match</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Whether you're printing family photos or business reports, we have the right printer for you
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-cyan-light/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative bg-card border border-border rounded-2xl p-8 h-full hover:border-primary/30 transition-colors duration-300">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <category.icon className="w-8 h-8 text-primary" />
                </div>

                <h3 className="font-display text-2xl font-bold text-foreground mb-3">
                  {category.title}
                </h3>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {category.description}
                </p>

                <div className="flex items-center justify-between text-sm text-muted-foreground mb-6">
                  <span>{category.printers} models</span>
                  <span>From ${category.startingPrice}</span>
                </div>

                <Button variant="ghost" className="group/btn w-full justify-between">
                  Browse Category
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
