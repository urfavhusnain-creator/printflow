import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-24 bg-hero relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/20 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-hero-foreground mb-6">
            Ready to Transform Your{" "}
            <span className="text-gradient">Printing Experience?</span>
          </h2>

          <p className="text-hero-muted text-lg md:text-xl max-w-2xl mx-auto mb-10">
            Join over 50,000 satisfied customers who trust PrintFlow for their printing needs. 
            Get started today with a free consultation.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="xl" className="group">
              Get Free Consultation
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="heroOutline" size="xl" className="group">
              <Phone className="w-5 h-5" />
              Call 1-800-PRINT
            </Button>
          </div>

          <p className="text-hero-muted/60 text-sm mt-6">
            No commitment required • Free shipping on all orders • 30-day money-back guarantee
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default CTA;
