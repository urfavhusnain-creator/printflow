import { motion } from "framer-motion";
import { Wifi, Zap, Shield, Leaf, Gauge, Headphones } from "lucide-react";

const features = [
  {
    icon: Wifi,
    title: "Wireless Connectivity",
    description: "Print from anywhere with WiFi, Bluetooth, and cloud integration support.",
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Industry-leading print speeds up to 60 pages per minute with zero warm-up.",
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Built-in security features to protect sensitive documents and data.",
  },
  {
    icon: Leaf,
    title: "Eco-Friendly",
    description: "Energy-efficient design with recyclable cartridges and sustainable materials.",
  },
  {
    icon: Gauge,
    title: "Precision Quality",
    description: "Crystal-clear prints with up to 4800 DPI resolution for stunning results.",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "Expert technical support available around the clock, whenever you need it.",
  },
];

const Features = () => {
  return (
    <section id="features" className="py-24 bg-hero relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-light/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-hero-foreground mb-4">
            Why Choose <span className="text-gradient">PrintFlow</span>
          </h2>
          <p className="text-hero-muted text-lg max-w-2xl mx-auto">
            Cutting-edge technology meets unparalleled reliability in every printer we make
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="gradient-border rounded-xl p-6 bg-surface-dark h-full hover:scale-105 transition-transform duration-300">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-semibold text-hero-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-hero-muted text-sm leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
