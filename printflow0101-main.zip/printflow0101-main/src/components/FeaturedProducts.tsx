import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, ShoppingCart } from "lucide-react";
import printerHome from "@/assets/printer-home.png";
import printerOffice from "@/assets/printer-office.png";
import printerPro from "@/assets/printer-pro.png";

const products = [
  {
    id: 1,
    name: "HomeJet Pro 500",
    category: "Home",
    price: 199,
    originalPrice: 249,
    rating: 4.8,
    reviews: 1240,
    image: printerHome,
    badge: "Best Seller",
    features: ["Wireless", "Compact", "Eco-Friendly"],
  },
  {
    id: 2,
    name: "OfficeMaster X1",
    category: "Office",
    price: 499,
    originalPrice: 599,
    rating: 4.9,
    reviews: 856,
    image: printerOffice,
    badge: "New",
    features: ["High Speed", "Duplex", "Network Ready"],
  },
  {
    id: 3,
    name: "ProStudio 4000",
    category: "Professional",
    price: 1299,
    originalPrice: 1499,
    rating: 5.0,
    reviews: 423,
    image: printerPro,
    badge: "Premium",
    features: ["Large Format", "Gallery Quality", "ICC Profiles"],
  },
];

const FeaturedProducts = () => {
  return (
    <section id="products" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Featured <span className="text-gradient">Printers</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Explore our most popular models, trusted by thousands of customers worldwide
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="group overflow-hidden border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5">
                <CardContent className="p-0">
                  {/* Image Container */}
                  <div className="relative bg-secondary/30 p-8 overflow-hidden">
                    <Badge 
                      variant="default" 
                      className="absolute top-4 left-4 z-10 bg-primary text-primary-foreground"
                    >
                      {product.badge}
                    </Badge>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-48 object-contain group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs text-muted-foreground uppercase tracking-wider">
                        {product.category}
                      </span>
                    </div>

                    <h3 className="font-display text-xl font-bold text-foreground mb-2">
                      {product.name}
                    </h3>

                    {/* Rating */}
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-primary text-primary" />
                        <span className="font-semibold text-foreground">{product.rating}</span>
                      </div>
                      <span className="text-muted-foreground text-sm">
                        ({product.reviews} reviews)
                      </span>
                    </div>

                    {/* Features */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {product.features.map((feature) => (
                        <span
                          key={feature}
                          className="text-xs bg-secondary px-2 py-1 rounded-full text-secondary-foreground"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>

                    {/* Price */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-foreground">
                          ${product.price}
                        </span>
                        <span className="text-muted-foreground line-through text-sm">
                          ${product.originalPrice}
                        </span>
                      </div>
                      <Button size="sm" className="group/btn">
                        <ShoppingCart className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button variant="outline" size="lg">
            View All Products
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
