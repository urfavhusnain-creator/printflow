import { Printer, Facebook, Twitter, Instagram, Youtube, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Footer = () => {
  const links = {
    products: ["Home Printers", "Office Printers", "Professional Series", "Ink & Toner", "Accessories"],
    company: ["About Us", "Careers", "Press", "Partners", "Sustainability"],
    support: ["Contact Us", "Help Center", "Warranty", "Returns", "Drivers & Software"],
    legal: ["Privacy Policy", "Terms of Service", "Cookie Policy", "Accessibility"],
  };

  return (
    <footer className="bg-surface-darker border-t border-hero-foreground/10">
      <div className="container mx-auto px-6 py-16">
        {/* Newsletter */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8 pb-12 border-b border-hero-foreground/10">
          <div>
            <h3 className="font-display text-xl font-bold text-hero-foreground mb-2">
              Stay Updated
            </h3>
            <p className="text-hero-muted">
              Get the latest news, product updates, and exclusive offers.
            </p>
          </div>
          <div className="flex gap-3 w-full lg:w-auto">
            <Input
              placeholder="Enter your email"
              className="bg-hero border-hero-foreground/20 text-hero-foreground placeholder:text-hero-muted max-w-xs"
            />
            <Button variant="hero">
              <Mail className="w-4 h-4 mr-2" />
              Subscribe
            </Button>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 py-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="/" className="flex items-center gap-3 mb-4">
              <Printer className="w-8 h-8 text-primary" />
              <span className="text-hero-foreground font-display text-xl font-bold">
                Print<span className="text-gradient">Flow</span>
              </span>
            </a>
            <p className="text-hero-muted text-sm mb-6">
              Revolutionizing the way the world prints since 2010.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, index) => (
                <a
                  key={index}
                  href="#"
                  className="w-10 h-10 rounded-full bg-hero-foreground/5 flex items-center justify-center text-hero-muted hover:text-primary hover:bg-hero-foreground/10 transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4 className="font-display font-semibold text-hero-foreground mb-4 capitalize">
                {category}
              </h4>
              <ul className="space-y-3">
                {items.map((item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="text-hero-muted hover:text-hero-foreground transition-colors text-sm"
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-hero-foreground/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-hero-muted text-sm">
            © 2024 PrintFlow. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-hero-muted hover:text-hero-foreground text-sm transition-colors">
              Privacy
            </a>
            <a href="#" className="text-hero-muted hover:text-hero-foreground text-sm transition-colors">
              Terms
            </a>
            <a href="#" className="text-hero-muted hover:text-hero-foreground text-sm transition-colors">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
